#include <cstdlib>
#include <iostream>
#include <fstream>

using namespace std;
 
int main () {
	FILE *m1 = fopen("matriz1.txt","r");
	FILE *m2 = fopen("matriz2.txt","r");
	
	if(m1==NULL){
		perror("No se encuentra el archivo con el nombre matriz1.txt");		
	}
	if(m2==NULL){
		perror("No se encuentra el archivo con el nombre matriz2.txt");		
	}
	
	char temp1[3];
	char temp2[3];
	char cadena1[2];
	char desperdicio[2];
	
	int bandera=0;
		
	int fil1=0;	
	int col1=0;
	int number=0;
	int i=0;
	int j=0;
	
	fgets(temp1,3,m1);
	fgets(temp2,3,m1);
	fil1=atoi(temp1);
	col1=atoi(temp2);
	
	int matriz1[fil1][col1];
	
	for(int i=0;i<fil1;i++){
		for(int j=0;j<col1;j++){
			fgets(cadena1,2,m1);
			number=atoi(cadena1);
			matriz1[i][j]=number;
			cout<<"["<<i<<"]"<<"["<<j<<"]: "<<matriz1[i][j]<<endl;
			if(fgets(desperdicio,2,m1)==NULL)
			{
				break;
			}	
		}
	}
	
	for(int f=0;f<fil1;f++){
		for(int c=0;c<col1;c++){
			cout<<matriz1[f][c]<<",";
		}
		cout<<endl;
	}
	
	cout<<"fila: "<<fil1<<" columna: "<<col1<<endl;
	
	int fil2=0;
	int col2=0;
	
	char cadena2[2];
	
	char temp3[3];
	char temp4[3];
	
	fgets(temp3,3,m2);
	fgets(temp4,3,m2);
	
	fil2=atoi(temp3);
	col2=atoi(temp4);
	
	i=0;
	j=0;
	
	int matriz2[fil2][col2];
	bandera=0;
	
	for(int i=0;i<fil1;i++){
		for(int j=0;j<col1;j++){
			fgets(cadena2,2,m2);
			number=atoi(cadena2);
			matriz2[i][j]=number;
			cout<<"["<<i<<"]"<<"["<<j<<"]: "<<matriz2[i][j]<<endl;
			if(fgets(desperdicio,2,m2)==NULL)
			{
				break;
			}	
		}
	}
		
	
	cout<<"fila: "<<fil2<<" columna: "<<col2<<endl;
	
	for(int f=0;f<fil1;f++){
		for(int c=0;c<col1;c++){
			cout<<matriz2[f][c]<<",";
		}
		cout<<endl;
	}
	
	int resul=0;
	int total=0;
	
	int result[fil1][col1];
	for(int f1=0;f1<fil1;f1=f1+1){
		for(int c1=0;c1<col1;c1=c1+1){
			number=matriz1[f1][c1];
			cout<<"Numero de la primer matriz: "<<number<<endl;
			
			for(int f2=0;f2<fil2;f2=f2+1){
				resul=matriz2[f2][c1]*number;
				cout<<"numero a multiplicar de la segunda matriz: "<<matriz2[f2][c1]<<endl;
				cout<<"resultado de la multiplicacion: "<<resul<<endl;
				total=resul+total;
			}
			result[f1][c1]=total;
			cout<< "numero en la posicion [" << f1 << "] " << "[" << c1 << "]" << ": " << total <<endl;
			total=0;
		}
	}
	fclose(m1);
	fclose(m2);
		
	ofstream fs("Resultado.txt"); 

   
   fs <<fil1<<endl;
   fs <<col1<<endl;
   		
	for(int f=0;f<fil1;f++){
		for(int c=0;c<col1;c++){
			fs<<result[f][c]<<",";
		}
		fs<<endl;
	}
	fs.close();
	
system("PAUSE");
return 0;
	
}
